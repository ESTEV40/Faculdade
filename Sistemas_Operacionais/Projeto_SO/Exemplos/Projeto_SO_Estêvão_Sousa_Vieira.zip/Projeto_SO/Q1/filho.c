//Estêvão Sousa Vieira - 202210345

// filho.c
#include <stdio.h>

int main() {
    // Processo filho imprime uma mensagem para o professor
    printf("Eai Louro, qual a boa?\n");
    return 0;
}
